﻿namespace FeesManagementProject
{
    partial class Update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtfullnameU = new System.Windows.Forms.TextBox();
            this.txtcellnoU = new System.Windows.Forms.TextBox();
            this.txtemailU = new System.Windows.Forms.TextBox();
            this.txteducationU = new System.Windows.Forms.TextBox();
            this.txtamountU = new System.Windows.Forms.TextBox();
            this.txtpaidU = new System.Windows.Forms.TextBox();
            this.txtremainU = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.cmbcourseU = new System.Windows.Forms.ComboBox();
            this.cmbdurationU = new System.Windows.Forms.ComboBox();
            this.cmbtypeU = new System.Windows.Forms.ComboBox();
            this.dataGridView1Update = new System.Windows.Forms.DataGridView();
            this.stdidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stdnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stdcontactDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stdemailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stdeducationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stdcourseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stddurationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stdtypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stddateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stdamountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stdpaidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stdremainDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.student_fess_project_SQLDataSet1 = new FeesManagementProject.student_fess_project_SQLDataSet1();
            this.btncloseU = new System.Windows.Forms.Button();
            this.btnresetU = new System.Windows.Forms.Button();
            this.btnsaveU = new System.Windows.Forms.Button();
            this.lblremainU = new System.Windows.Forms.Label();
            this.lblpaidU = new System.Windows.Forms.Label();
            this.lblamountU = new System.Windows.Forms.Label();
            this.lbldateU = new System.Windows.Forms.Label();
            this.lbltypeU = new System.Windows.Forms.Label();
            this.lbldurationU = new System.Windows.Forms.Label();
            this.lblcourseU = new System.Windows.Forms.Label();
            this.lbleducationU = new System.Windows.Forms.Label();
            this.lblemailU = new System.Windows.Forms.Label();
            this.lblcellnoU = new System.Windows.Forms.Label();
            this.lblfullnameU = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.studentTableAdapter = new FeesManagementProject.student_fess_project_SQLDataSet1TableAdapters.StudentTableAdapter();
            this.btnupdateU = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1Update)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_fess_project_SQLDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtfullnameU
            // 
            this.txtfullnameU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfullnameU.Location = new System.Drawing.Point(222, 25);
            this.txtfullnameU.Name = "txtfullnameU";
            this.txtfullnameU.Size = new System.Drawing.Size(238, 24);
            this.txtfullnameU.TabIndex = 10;
            // 
            // txtcellnoU
            // 
            this.txtcellnoU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcellnoU.Location = new System.Drawing.Point(222, 70);
            this.txtcellnoU.Name = "txtcellnoU";
            this.txtcellnoU.Size = new System.Drawing.Size(238, 24);
            this.txtcellnoU.TabIndex = 11;
            // 
            // txtemailU
            // 
            this.txtemailU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemailU.Location = new System.Drawing.Point(222, 119);
            this.txtemailU.Name = "txtemailU";
            this.txtemailU.Size = new System.Drawing.Size(238, 24);
            this.txtemailU.TabIndex = 12;
            // 
            // txteducationU
            // 
            this.txteducationU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txteducationU.Location = new System.Drawing.Point(222, 167);
            this.txteducationU.Name = "txteducationU";
            this.txteducationU.Size = new System.Drawing.Size(238, 24);
            this.txteducationU.TabIndex = 13;
            // 
            // txtamountU
            // 
            this.txtamountU.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtamountU.Location = new System.Drawing.Point(208, 226);
            this.txtamountU.Name = "txtamountU";
            this.txtamountU.Size = new System.Drawing.Size(165, 26);
            this.txtamountU.TabIndex = 19;
            // 
            // txtpaidU
            // 
            this.txtpaidU.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpaidU.Location = new System.Drawing.Point(553, 226);
            this.txtpaidU.Name = "txtpaidU";
            this.txtpaidU.Size = new System.Drawing.Size(165, 26);
            this.txtpaidU.TabIndex = 21;
            this.txtpaidU.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // txtremainU
            // 
            this.txtremainU.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtremainU.Location = new System.Drawing.Point(903, 228);
            this.txtremainU.Name = "txtremainU";
            this.txtremainU.Size = new System.Drawing.Size(165, 26);
            this.txtremainU.TabIndex = 23;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(808, 171);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(238, 24);
            this.dateTimePicker1.TabIndex = 27;
            // 
            // cmbcourseU
            // 
            this.cmbcourseU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbcourseU.FormattingEnabled = true;
            this.cmbcourseU.Items.AddRange(new object[] {
            "Website Design",
            "PHP",
            "ASP.NET",
            "JAVA",
            "C++",
            "Advanced JAVA",
            "Android"});
            this.cmbcourseU.Location = new System.Drawing.Point(808, 24);
            this.cmbcourseU.Name = "cmbcourseU";
            this.cmbcourseU.Size = new System.Drawing.Size(238, 25);
            this.cmbcourseU.TabIndex = 28;
            this.cmbcourseU.Text = "--Select--";
            // 
            // cmbdurationU
            // 
            this.cmbdurationU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbdurationU.FormattingEnabled = true;
            this.cmbdurationU.Items.AddRange(new object[] {
            "2 Months",
            "3 Months",
            "6 Months",
            "1 Year"});
            this.cmbdurationU.Location = new System.Drawing.Point(808, 70);
            this.cmbdurationU.Name = "cmbdurationU";
            this.cmbdurationU.Size = new System.Drawing.Size(238, 25);
            this.cmbdurationU.TabIndex = 29;
            this.cmbdurationU.Text = "--Select--";
            // 
            // cmbtypeU
            // 
            this.cmbtypeU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbtypeU.FormattingEnabled = true;
            this.cmbtypeU.Items.AddRange(new object[] {
            "Training",
            "Training + Interview",
            "Training + Placement"});
            this.cmbtypeU.Location = new System.Drawing.Point(808, 118);
            this.cmbtypeU.Name = "cmbtypeU";
            this.cmbtypeU.Size = new System.Drawing.Size(238, 25);
            this.cmbtypeU.TabIndex = 30;
            this.cmbtypeU.Text = "--Select--";
            // 
            // dataGridView1Update
            // 
            this.dataGridView1Update.AutoGenerateColumns = false;
            this.dataGridView1Update.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1Update.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stdidDataGridViewTextBoxColumn,
            this.stdnameDataGridViewTextBoxColumn,
            this.stdcontactDataGridViewTextBoxColumn,
            this.stdemailDataGridViewTextBoxColumn,
            this.stdeducationDataGridViewTextBoxColumn,
            this.stdcourseDataGridViewTextBoxColumn,
            this.stddurationDataGridViewTextBoxColumn,
            this.stdtypeDataGridViewTextBoxColumn,
            this.stddateDataGridViewTextBoxColumn,
            this.stdamountDataGridViewTextBoxColumn,
            this.stdpaidDataGridViewTextBoxColumn,
            this.stdremainDataGridViewTextBoxColumn});
            this.dataGridView1Update.DataSource = this.studentBindingSource;
            this.dataGridView1Update.Location = new System.Drawing.Point(28, 305);
            this.dataGridView1Update.Name = "dataGridView1Update";
            this.dataGridView1Update.Size = new System.Drawing.Size(1040, 312);
            this.dataGridView1Update.TabIndex = 31;
            // 
            // stdidDataGridViewTextBoxColumn
            // 
            this.stdidDataGridViewTextBoxColumn.DataPropertyName = "std_id";
            this.stdidDataGridViewTextBoxColumn.HeaderText = "std_id";
            this.stdidDataGridViewTextBoxColumn.Name = "stdidDataGridViewTextBoxColumn";
            this.stdidDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // stdnameDataGridViewTextBoxColumn
            // 
            this.stdnameDataGridViewTextBoxColumn.DataPropertyName = "std_name";
            this.stdnameDataGridViewTextBoxColumn.HeaderText = "std_name";
            this.stdnameDataGridViewTextBoxColumn.Name = "stdnameDataGridViewTextBoxColumn";
            // 
            // stdcontactDataGridViewTextBoxColumn
            // 
            this.stdcontactDataGridViewTextBoxColumn.DataPropertyName = "std_contact";
            this.stdcontactDataGridViewTextBoxColumn.HeaderText = "std_contact";
            this.stdcontactDataGridViewTextBoxColumn.Name = "stdcontactDataGridViewTextBoxColumn";
            // 
            // stdemailDataGridViewTextBoxColumn
            // 
            this.stdemailDataGridViewTextBoxColumn.DataPropertyName = "std_email";
            this.stdemailDataGridViewTextBoxColumn.HeaderText = "std_email";
            this.stdemailDataGridViewTextBoxColumn.Name = "stdemailDataGridViewTextBoxColumn";
            // 
            // stdeducationDataGridViewTextBoxColumn
            // 
            this.stdeducationDataGridViewTextBoxColumn.DataPropertyName = "std_education";
            this.stdeducationDataGridViewTextBoxColumn.HeaderText = "std_education";
            this.stdeducationDataGridViewTextBoxColumn.Name = "stdeducationDataGridViewTextBoxColumn";
            // 
            // stdcourseDataGridViewTextBoxColumn
            // 
            this.stdcourseDataGridViewTextBoxColumn.DataPropertyName = "std_course";
            this.stdcourseDataGridViewTextBoxColumn.HeaderText = "std_course";
            this.stdcourseDataGridViewTextBoxColumn.Name = "stdcourseDataGridViewTextBoxColumn";
            // 
            // stddurationDataGridViewTextBoxColumn
            // 
            this.stddurationDataGridViewTextBoxColumn.DataPropertyName = "std_duration";
            this.stddurationDataGridViewTextBoxColumn.HeaderText = "std_duration";
            this.stddurationDataGridViewTextBoxColumn.Name = "stddurationDataGridViewTextBoxColumn";
            // 
            // stdtypeDataGridViewTextBoxColumn
            // 
            this.stdtypeDataGridViewTextBoxColumn.DataPropertyName = "std_type";
            this.stdtypeDataGridViewTextBoxColumn.HeaderText = "std_type";
            this.stdtypeDataGridViewTextBoxColumn.Name = "stdtypeDataGridViewTextBoxColumn";
            // 
            // stddateDataGridViewTextBoxColumn
            // 
            this.stddateDataGridViewTextBoxColumn.DataPropertyName = "std_date";
            this.stddateDataGridViewTextBoxColumn.HeaderText = "std_date";
            this.stddateDataGridViewTextBoxColumn.Name = "stddateDataGridViewTextBoxColumn";
            // 
            // stdamountDataGridViewTextBoxColumn
            // 
            this.stdamountDataGridViewTextBoxColumn.DataPropertyName = "std_amount";
            this.stdamountDataGridViewTextBoxColumn.HeaderText = "std_amount";
            this.stdamountDataGridViewTextBoxColumn.Name = "stdamountDataGridViewTextBoxColumn";
            // 
            // stdpaidDataGridViewTextBoxColumn
            // 
            this.stdpaidDataGridViewTextBoxColumn.DataPropertyName = "std_paid";
            this.stdpaidDataGridViewTextBoxColumn.HeaderText = "std_paid";
            this.stdpaidDataGridViewTextBoxColumn.Name = "stdpaidDataGridViewTextBoxColumn";
            // 
            // stdremainDataGridViewTextBoxColumn
            // 
            this.stdremainDataGridViewTextBoxColumn.DataPropertyName = "std_remain";
            this.stdremainDataGridViewTextBoxColumn.HeaderText = "std_remain";
            this.stdremainDataGridViewTextBoxColumn.Name = "stdremainDataGridViewTextBoxColumn";
            // 
            // studentBindingSource
            // 
            this.studentBindingSource.DataMember = "Student";
            this.studentBindingSource.DataSource = this.student_fess_project_SQLDataSet1;
            // 
            // student_fess_project_SQLDataSet1
            // 
            this.student_fess_project_SQLDataSet1.DataSetName = "student_fess_project_SQLDataSet1";
            this.student_fess_project_SQLDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btncloseU
            // 
            this.btncloseU.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncloseU.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btncloseU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncloseU.Image = global::FeesManagementProject.Properties.Resources.header;
            this.btncloseU.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btncloseU.Location = new System.Drawing.Point(734, 270);
            this.btncloseU.Name = "btncloseU";
            this.btncloseU.Size = new System.Drawing.Size(97, 29);
            this.btncloseU.TabIndex = 26;
            this.btncloseU.Text = "Close";
            this.btncloseU.UseVisualStyleBackColor = true;
            this.btncloseU.Click += new System.EventHandler(this.btncloseU_Click);
            // 
            // btnresetU
            // 
            this.btnresetU.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnresetU.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnresetU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnresetU.Image = global::FeesManagementProject.Properties.Resources.header;
            this.btnresetU.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnresetU.Location = new System.Drawing.Point(585, 270);
            this.btnresetU.Name = "btnresetU";
            this.btnresetU.Size = new System.Drawing.Size(98, 29);
            this.btnresetU.TabIndex = 25;
            this.btnresetU.Text = "Reset";
            this.btnresetU.UseVisualStyleBackColor = true;
            this.btnresetU.Click += new System.EventHandler(this.btnresetU_Click);
            // 
            // btnsaveU
            // 
            this.btnsaveU.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsaveU.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnsaveU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsaveU.Image = global::FeesManagementProject.Properties.Resources.header;
            this.btnsaveU.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnsaveU.Location = new System.Drawing.Point(270, 270);
            this.btnsaveU.Name = "btnsaveU";
            this.btnsaveU.Size = new System.Drawing.Size(101, 29);
            this.btnsaveU.TabIndex = 24;
            this.btnsaveU.Text = "Save";
            this.btnsaveU.UseVisualStyleBackColor = true;
            this.btnsaveU.Click += new System.EventHandler(this.btnsaveU_Click);
            // 
            // lblremainU
            // 
            this.lblremainU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblremainU.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblremainU.Image = global::FeesManagementProject.Properties.Resources.header;
            this.lblremainU.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblremainU.Location = new System.Drawing.Point(769, 226);
            this.lblremainU.Name = "lblremainU";
            this.lblremainU.Size = new System.Drawing.Size(128, 28);
            this.lblremainU.TabIndex = 22;
            this.lblremainU.Text = "Remain";
            this.lblremainU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblpaidU
            // 
            this.lblpaidU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpaidU.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblpaidU.Image = global::FeesManagementProject.Properties.Resources.header;
            this.lblpaidU.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblpaidU.Location = new System.Drawing.Point(419, 224);
            this.lblpaidU.Name = "lblpaidU";
            this.lblpaidU.Size = new System.Drawing.Size(128, 28);
            this.lblpaidU.TabIndex = 20;
            this.lblpaidU.Text = "Paid";
            this.lblpaidU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblamountU
            // 
            this.lblamountU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblamountU.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblamountU.Image = global::FeesManagementProject.Properties.Resources.header;
            this.lblamountU.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblamountU.Location = new System.Drawing.Point(74, 224);
            this.lblamountU.Name = "lblamountU";
            this.lblamountU.Size = new System.Drawing.Size(128, 28);
            this.lblamountU.TabIndex = 18;
            this.lblamountU.Text = "Amount";
            this.lblamountU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbldateU
            // 
            this.lbldateU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldateU.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbldateU.Image = global::FeesManagementProject.Properties.Resources.header;
            this.lbldateU.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbldateU.Location = new System.Drawing.Point(617, 163);
            this.lbldateU.Name = "lbldateU";
            this.lbldateU.Size = new System.Drawing.Size(147, 28);
            this.lbldateU.TabIndex = 9;
            this.lbldateU.Text = "Date";
            this.lbldateU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbltypeU
            // 
            this.lbltypeU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltypeU.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbltypeU.Image = global::FeesManagementProject.Properties.Resources.header;
            this.lbltypeU.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbltypeU.Location = new System.Drawing.Point(617, 115);
            this.lbltypeU.Name = "lbltypeU";
            this.lbltypeU.Size = new System.Drawing.Size(147, 28);
            this.lbltypeU.TabIndex = 8;
            this.lbltypeU.Text = "Type";
            this.lbltypeU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbltypeU.Click += new System.EventHandler(this.lbltypeU_Click);
            // 
            // lbldurationU
            // 
            this.lbldurationU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldurationU.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbldurationU.Image = global::FeesManagementProject.Properties.Resources.header;
            this.lbldurationU.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbldurationU.Location = new System.Drawing.Point(617, 66);
            this.lbldurationU.Name = "lbldurationU";
            this.lbldurationU.Size = new System.Drawing.Size(147, 28);
            this.lbldurationU.TabIndex = 7;
            this.lbldurationU.Text = "Duration";
            this.lbldurationU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblcourseU
            // 
            this.lblcourseU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcourseU.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblcourseU.Image = global::FeesManagementProject.Properties.Resources.header;
            this.lblcourseU.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblcourseU.Location = new System.Drawing.Point(617, 21);
            this.lblcourseU.Name = "lblcourseU";
            this.lblcourseU.Size = new System.Drawing.Size(147, 28);
            this.lblcourseU.TabIndex = 6;
            this.lblcourseU.Text = "Course";
            this.lblcourseU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbleducationU
            // 
            this.lbleducationU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbleducationU.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbleducationU.Image = global::FeesManagementProject.Properties.Resources.header;
            this.lbleducationU.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbleducationU.Location = new System.Drawing.Point(55, 163);
            this.lbleducationU.Name = "lbleducationU";
            this.lbleducationU.Size = new System.Drawing.Size(147, 28);
            this.lbleducationU.TabIndex = 5;
            this.lbleducationU.Text = "Education";
            this.lbleducationU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblemailU
            // 
            this.lblemailU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemailU.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblemailU.Image = global::FeesManagementProject.Properties.Resources.header;
            this.lblemailU.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblemailU.Location = new System.Drawing.Point(55, 115);
            this.lblemailU.Name = "lblemailU";
            this.lblemailU.Size = new System.Drawing.Size(147, 28);
            this.lblemailU.TabIndex = 4;
            this.lblemailU.Text = "Email";
            this.lblemailU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblcellnoU
            // 
            this.lblcellnoU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcellnoU.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblcellnoU.Image = global::FeesManagementProject.Properties.Resources.header;
            this.lblcellnoU.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblcellnoU.Location = new System.Drawing.Point(55, 66);
            this.lblcellnoU.Name = "lblcellnoU";
            this.lblcellnoU.Size = new System.Drawing.Size(147, 28);
            this.lblcellnoU.TabIndex = 3;
            this.lblcellnoU.Text = "Cell No";
            this.lblcellnoU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblfullnameU
            // 
            this.lblfullnameU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfullnameU.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblfullnameU.Image = global::FeesManagementProject.Properties.Resources.header;
            this.lblfullnameU.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblfullnameU.Location = new System.Drawing.Point(55, 21);
            this.lblfullnameU.Name = "lblfullnameU";
            this.lblfullnameU.Size = new System.Drawing.Size(147, 28);
            this.lblfullnameU.TabIndex = 2;
            this.lblfullnameU.Text = "Full Name";
            this.lblfullnameU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::FeesManagementProject.Properties.Resources.header;
            this.pictureBox1.Location = new System.Drawing.Point(-3, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1118, 630);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // studentTableAdapter
            // 
            this.studentTableAdapter.ClearBeforeFill = true;
            // 
            // btnupdateU
            // 
            this.btnupdateU.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnupdateU.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnupdateU.Font = new System.Drawing.Font("Baskerville Old Face", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdateU.Image = global::FeesManagementProject.Properties.Resources.header;
            this.btnupdateU.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnupdateU.Location = new System.Drawing.Point(427, 270);
            this.btnupdateU.Name = "btnupdateU";
            this.btnupdateU.Size = new System.Drawing.Size(98, 29);
            this.btnupdateU.TabIndex = 32;
            this.btnupdateU.Text = "Update";
            this.btnupdateU.UseVisualStyleBackColor = true;
            this.btnupdateU.Click += new System.EventHandler(this.btnupdateU_Click);
            // 
            // Update
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1103, 629);
            this.Controls.Add(this.btnupdateU);
            this.Controls.Add(this.dataGridView1Update);
            this.Controls.Add(this.cmbtypeU);
            this.Controls.Add(this.cmbdurationU);
            this.Controls.Add(this.cmbcourseU);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btncloseU);
            this.Controls.Add(this.btnresetU);
            this.Controls.Add(this.btnsaveU);
            this.Controls.Add(this.txtremainU);
            this.Controls.Add(this.lblremainU);
            this.Controls.Add(this.txtpaidU);
            this.Controls.Add(this.lblpaidU);
            this.Controls.Add(this.txtamountU);
            this.Controls.Add(this.lblamountU);
            this.Controls.Add(this.txteducationU);
            this.Controls.Add(this.txtemailU);
            this.Controls.Add(this.txtcellnoU);
            this.Controls.Add(this.txtfullnameU);
            this.Controls.Add(this.lbldateU);
            this.Controls.Add(this.lbltypeU);
            this.Controls.Add(this.lbldurationU);
            this.Controls.Add(this.lblcourseU);
            this.Controls.Add(this.lbleducationU);
            this.Controls.Add(this.lblemailU);
            this.Controls.Add(this.lblcellnoU);
            this.Controls.Add(this.lblfullnameU);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Update";
            this.Text = "Update";
            this.Load += new System.EventHandler(this.Update_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1Update)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.student_fess_project_SQLDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblfullnameU;
        private System.Windows.Forms.Label lblcellnoU;
        private System.Windows.Forms.Label lblemailU;
        private System.Windows.Forms.Label lbleducationU;
        private System.Windows.Forms.Label lblcourseU;
        private System.Windows.Forms.Label lbldurationU;
        private System.Windows.Forms.Label lbltypeU;
        private System.Windows.Forms.Label lbldateU;
        private System.Windows.Forms.TextBox txtfullnameU;
        private System.Windows.Forms.TextBox txtcellnoU;
        private System.Windows.Forms.TextBox txtemailU;
        private System.Windows.Forms.TextBox txteducationU;
        private System.Windows.Forms.Label lblamountU;
        private System.Windows.Forms.TextBox txtamountU;
        private System.Windows.Forms.Label lblpaidU;
        private System.Windows.Forms.TextBox txtpaidU;
        private System.Windows.Forms.Label lblremainU;
        private System.Windows.Forms.TextBox txtremainU;
        private System.Windows.Forms.Button btnsaveU;
        private System.Windows.Forms.Button btnresetU;
        private System.Windows.Forms.Button btncloseU;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox cmbcourseU;
        private System.Windows.Forms.ComboBox cmbdurationU;
        private System.Windows.Forms.ComboBox cmbtypeU;
        private System.Windows.Forms.DataGridView dataGridView1Update;
        private student_fess_project_SQLDataSet1 student_fess_project_SQLDataSet1;
        private System.Windows.Forms.BindingSource studentBindingSource;
        private student_fess_project_SQLDataSet1TableAdapters.StudentTableAdapter studentTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn stdidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stdnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stdcontactDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stdemailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stdeducationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stdcourseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stddurationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stdtypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stddateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stdamountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stdpaidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stdremainDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnupdateU;
    }
}