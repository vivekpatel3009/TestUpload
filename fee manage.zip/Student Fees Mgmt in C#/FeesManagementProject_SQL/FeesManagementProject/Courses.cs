﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FeesManagementProject
{
    public partial class Courses : Form
    {
        public Courses()
        {
            InitializeComponent();
        }
    }
}
