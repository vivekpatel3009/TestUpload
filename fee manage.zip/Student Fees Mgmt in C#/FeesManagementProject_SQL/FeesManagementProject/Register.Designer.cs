﻿namespace FeesManagementProject
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtusernameR = new System.Windows.Forms.TextBox();
            this.txtemailR = new System.Windows.Forms.TextBox();
            this.btnregisterR = new System.Windows.Forms.Button();
            this.btncloseR = new System.Windows.Forms.Button();
            this.btnresetR = new System.Windows.Forms.Button();
            this.lblemailR = new System.Windows.Forms.Label();
            this.lblusernameR = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.llblpasswordR = new System.Windows.Forms.Label();
            this.lblmobileno = new System.Windows.Forms.Label();
            this.txtmobileR = new System.Windows.Forms.TextBox();
            this.txtpasswordR = new System.Windows.Forms.TextBox();
            this.lblCpasswordR = new System.Windows.Forms.Label();
            this.txtCpassword = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtusernameR
            // 
            this.txtusernameR.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtusernameR.Location = new System.Drawing.Point(581, 88);
            this.txtusernameR.Name = "txtusernameR";
            this.txtusernameR.Size = new System.Drawing.Size(204, 26);
            this.txtusernameR.TabIndex = 3;
            // 
            // txtemailR
            // 
            this.txtemailR.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemailR.Location = new System.Drawing.Point(581, 155);
            this.txtemailR.Name = "txtemailR";
            this.txtemailR.Size = new System.Drawing.Size(204, 26);
            this.txtemailR.TabIndex = 4;
            this.txtemailR.TextChanged += new System.EventHandler(this.txtemailR_TextChanged);
            // 
            // btnregisterR
            // 
            this.btnregisterR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnregisterR.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnregisterR.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregisterR.Image = global::FeesManagementProject.Properties.Resources.header;
            this.btnregisterR.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnregisterR.Location = new System.Drawing.Point(705, 463);
            this.btnregisterR.Name = "btnregisterR";
            this.btnregisterR.Size = new System.Drawing.Size(93, 31);
            this.btnregisterR.TabIndex = 7;
            this.btnregisterR.Text = "Register";
            this.btnregisterR.UseVisualStyleBackColor = true;
            this.btnregisterR.Click += new System.EventHandler(this.btnregisterR_Click);
            // 
            // btncloseR
            // 
            this.btncloseR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncloseR.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btncloseR.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncloseR.Image = global::FeesManagementProject.Properties.Resources.header;
            this.btncloseR.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btncloseR.Location = new System.Drawing.Point(507, 463);
            this.btncloseR.Name = "btncloseR";
            this.btncloseR.Size = new System.Drawing.Size(93, 31);
            this.btncloseR.TabIndex = 6;
            this.btncloseR.Text = "Close";
            this.btncloseR.UseVisualStyleBackColor = true;
            this.btncloseR.Click += new System.EventHandler(this.btncloseR_Click);
            // 
            // btnresetR
            // 
            this.btnresetR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnresetR.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnresetR.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnresetR.Image = global::FeesManagementProject.Properties.Resources.header;
            this.btnresetR.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnresetR.Location = new System.Drawing.Point(319, 463);
            this.btnresetR.Name = "btnresetR";
            this.btnresetR.Size = new System.Drawing.Size(93, 31);
            this.btnresetR.TabIndex = 5;
            this.btnresetR.Text = "Reset";
            this.btnresetR.UseVisualStyleBackColor = true;
            this.btnresetR.Click += new System.EventHandler(this.btnresetR_Click);
            // 
            // lblemailR
            // 
            this.lblemailR.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemailR.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblemailR.Image = global::FeesManagementProject.Properties.Resources.header;
            this.lblemailR.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblemailR.Location = new System.Drawing.Point(356, 154);
            this.lblemailR.Name = "lblemailR";
            this.lblemailR.Size = new System.Drawing.Size(154, 27);
            this.lblemailR.TabIndex = 2;
            this.lblemailR.Text = "Email";
            this.lblemailR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblusernameR
            // 
            this.lblusernameR.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusernameR.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblusernameR.Image = global::FeesManagementProject.Properties.Resources.header;
            this.lblusernameR.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblusernameR.Location = new System.Drawing.Point(359, 88);
            this.lblusernameR.Name = "lblusernameR";
            this.lblusernameR.Size = new System.Drawing.Size(151, 27);
            this.lblusernameR.TabIndex = 1;
            this.lblusernameR.Text = "Username";
            this.lblusernameR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblusernameR.Click += new System.EventHandler(this.lblusernameR_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::FeesManagementProject.Properties.Resources.header;
            this.pictureBox1.Location = new System.Drawing.Point(1, -3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1102, 551);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // llblpasswordR
            // 
            this.llblpasswordR.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llblpasswordR.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.llblpasswordR.Image = global::FeesManagementProject.Properties.Resources.header;
            this.llblpasswordR.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.llblpasswordR.Location = new System.Drawing.Point(356, 300);
            this.llblpasswordR.Name = "llblpasswordR";
            this.llblpasswordR.Size = new System.Drawing.Size(154, 27);
            this.llblpasswordR.TabIndex = 8;
            this.llblpasswordR.Text = "Password";
            this.llblpasswordR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblmobileno
            // 
            this.lblmobileno.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmobileno.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblmobileno.Image = global::FeesManagementProject.Properties.Resources.header;
            this.lblmobileno.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblmobileno.Location = new System.Drawing.Point(356, 224);
            this.lblmobileno.Name = "lblmobileno";
            this.lblmobileno.Size = new System.Drawing.Size(154, 27);
            this.lblmobileno.TabIndex = 9;
            this.lblmobileno.Text = "Mobile No";
            this.lblmobileno.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtmobileR
            // 
            this.txtmobileR.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmobileR.Location = new System.Drawing.Point(581, 224);
            this.txtmobileR.Name = "txtmobileR";
            this.txtmobileR.Size = new System.Drawing.Size(204, 26);
            this.txtmobileR.TabIndex = 10;
            // 
            // txtpasswordR
            // 
            this.txtpasswordR.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpasswordR.Location = new System.Drawing.Point(581, 300);
            this.txtpasswordR.Name = "txtpasswordR";
            this.txtpasswordR.PasswordChar = '*';
            this.txtpasswordR.Size = new System.Drawing.Size(204, 26);
            this.txtpasswordR.TabIndex = 11;
            // 
            // lblCpasswordR
            // 
            this.lblCpasswordR.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCpasswordR.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCpasswordR.Image = global::FeesManagementProject.Properties.Resources.header;
            this.lblCpasswordR.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblCpasswordR.Location = new System.Drawing.Point(353, 375);
            this.lblCpasswordR.Name = "lblCpasswordR";
            this.lblCpasswordR.Size = new System.Drawing.Size(160, 27);
            this.lblCpasswordR.TabIndex = 12;
            this.lblCpasswordR.Text = "Confirm Password";
            this.lblCpasswordR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCpassword
            // 
            this.txtCpassword.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCpassword.Location = new System.Drawing.Point(581, 375);
            this.txtCpassword.Name = "txtCpassword";
            this.txtCpassword.PasswordChar = '*';
            this.txtCpassword.Size = new System.Drawing.Size(204, 26);
            this.txtCpassword.TabIndex = 13;
            this.txtCpassword.TextChanged += new System.EventHandler(this.txtCpassword_TextChanged);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Baskerville Old Face", 19F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Image = global::FeesManagementProject.Properties.Resources.header;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(358, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(430, 36);
            this.label1.TabIndex = 14;
            this.label1.Text = "Register";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Image = global::FeesManagementProject.Properties.Resources.header;
            this.label2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label2.Location = new System.Drawing.Point(730, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 36);
            this.label2.TabIndex = 15;
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 544);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCpassword);
            this.Controls.Add(this.lblCpasswordR);
            this.Controls.Add(this.txtpasswordR);
            this.Controls.Add(this.txtmobileR);
            this.Controls.Add(this.lblmobileno);
            this.Controls.Add(this.llblpasswordR);
            this.Controls.Add(this.btnregisterR);
            this.Controls.Add(this.btncloseR);
            this.Controls.Add(this.btnresetR);
            this.Controls.Add(this.txtemailR);
            this.Controls.Add(this.txtusernameR);
            this.Controls.Add(this.lblemailR);
            this.Controls.Add(this.lblusernameR);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Register";
            this.Text = "Register";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblusernameR;
        private System.Windows.Forms.Label lblemailR;
        private System.Windows.Forms.TextBox txtusernameR;
        private System.Windows.Forms.TextBox txtemailR;
        private System.Windows.Forms.Button btnresetR;
        private System.Windows.Forms.Button btncloseR;
        private System.Windows.Forms.Button btnregisterR;
        private System.Windows.Forms.Label llblpasswordR;
        private System.Windows.Forms.Label lblmobileno;
        private System.Windows.Forms.TextBox txtmobileR;
        private System.Windows.Forms.TextBox txtpasswordR;
        private System.Windows.Forms.Label lblCpasswordR;
        private System.Windows.Forms.TextBox txtCpassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}